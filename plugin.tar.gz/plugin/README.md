### To compile plugin<br />
**1)** cmake -DAspect_DIR=/home/axh1305/software/aspect_2-1-0/build-release/ .     # (pointing to your ASPECT_2-1-0 version)<br />
**2)** make

*See ASPECT manual, http://www.math.clemson.edu/~heister/manual.pdf, for more details.*
